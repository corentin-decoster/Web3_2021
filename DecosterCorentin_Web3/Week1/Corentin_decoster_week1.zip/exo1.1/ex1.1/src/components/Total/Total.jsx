import React from 'react'

const Total = (props) => {
    return (
        <div>
            <p>
                Number of exercises {props.exercices}
            </p>
        </div>
    )
}

export default Total